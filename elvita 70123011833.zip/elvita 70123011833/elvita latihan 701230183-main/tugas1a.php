<?php
// Buat variabel
$teks1 = "Topi";
$teks2 = " Bundar";
// Gunakan operator concat untuk menggabungkan string
echo "Topi Saya ".$teks2. "," .$teks2. " Topi Saya.";
?>
