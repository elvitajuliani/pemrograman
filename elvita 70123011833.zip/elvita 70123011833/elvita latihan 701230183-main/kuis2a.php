<?php
$angka= 1; 

while ($angka <= 16) {
    echo $angka . "\n";
    $angka += 5; 
}
?>