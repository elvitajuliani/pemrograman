<?php
// Deklarasi variabel dengan nilai awal 10
$angka = 10;

echo "Aku adalah angka $angka.<br>";

// Operasi pertama: dikali 8
$angka = $angka * 8;
echo "Jika aku dikali 8, jumlahku sekarang $angka.<br>";

// Operasi kedua: dibagi 4
$angka = $angka / 4;
echo "Jika aku dibagi 4, jumlahku sekarang $angka.<br>";

// Operasi ketiga: dikurangi 6
$angka = $angka - 6;
echo "Jika aku dikurang 6, jumlahku sekarang $angka.<br>";

// Operasi keempat: ditambah 2
$angka = $angka + 2;
echo "Jika aku ditambah 2, jumlahku sekarang $angka.<br>";
?>