<?php
// Inisialisasi nilai awal
$nomor_awal = 10; 
$nomor_akhir = 0;

// Gunakan while loop untuk menghasilkan urutan
while ($nomor_awal >= $nomor_akhir) {
echo $nomor_awal . "\n"; 
$nomor_awal--; 
}
?>